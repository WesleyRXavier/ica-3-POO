
public interface IContato {

    public String getNome();

    public int getTelefone();

}
