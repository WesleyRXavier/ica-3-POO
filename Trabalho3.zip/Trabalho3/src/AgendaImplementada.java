/*
TRABALHO 03 - ICA POO1
PROFESSOR: ROMULO
ALUNOS: JONATAS DEORCE,JEIKSON LORENZINI, WESLEY XAVIER
*/
import java.util.Arrays;

public class AgendaImplementada implements IAgenda {

    IContato[] contatos = new ContatoImplementado[1];// array comecando com 1 indice

   
    int posicaoVaga = 0;// contador conattos na agenda

    @Override // metodo pra adicionar contatos na agenda
    public void insereContato(IContato contato) {
        if (posicaoVaga < contatos.length) {// verifica se tem posicao vaga
            contatos[posicaoVaga] = contato;

        } else {
            IContato copiaContatos[] = new ContatoImplementado[contatos.length]; // cria arrays auxiliar do tamanho do original
            System.arraycopy(contatos, 0, copiaContatos, 0, contatos.length);   // copia todo conteudo do original pra o auxiliar apartior do indice 0
            contatos = new ContatoImplementado[contatos.length * 2];            // aumenta o tamanho do array original pra seu tamanho 2 vezes
            System.arraycopy(copiaContatos, 0, contatos, 0, copiaContatos.length);// copia os lemetos de volta ao array original
            contatos[posicaoVaga] = contato; // adiciona o contato na posica vaga
          

        }
        posicaoVaga++; // acrescenta 1 a posicao vaga
    }

    @Override// devolve o total de contatos
    public int totalContatos() {
        return posicaoVaga;
    }

    @Override// mostra os dados dos contatos dentro do array
    public void mostraDadosContatos() {
        for (int i = 0; i < posicaoVaga; i++) {
            System.out.println("Posicao " + i + " = " + contatos[i].toString());
        }

    }

    @Override//recebe um contato e se ele existe o remove
    public void removeContato(IContato contato) {
        int posicao = -1; // variavel auxiliar
        for (int i = 0; i < posicaoVaga; i++) {
            if (contatos[i].equals(contato) == true) {// verifica se o contato existe no array e atribui seu posicao
                posicao = i;
            }
        }
        if (posicao == -1) { //verifica se a posicao existe
            System.out.println("Nao existe este contato");
        } else {
            for (; posicao < posicaoVaga; posicao++) {  //percorre o array puxa o proximo contato para a posicao que foi eliminada
                contatos[posicao] = contatos[posicao + 1];
            }
            posicaoVaga--;
        }

    }

    @Override// remove todos os contatos
    public void removeTodos() {
        posicaoVaga = 0;
        //Arrays.fill(contatos, null);// atribui nulll pra todas as posicoes do array
        contatos = new ContatoImplementado[1];// redimensiona os array (zera)

    }

    @Override// devolve o contatos na posicao passada
    public IContato selecionaContato(int posicao) {
        if (validaPosicao(posicao)== true) {
            return contatos[posicao];
        } else {
            System.out.println("Não existe esta posicao na agenda!!");
        }
        return null;

    }

    @Override//devolve a posicao do contato passado
    public int posicao(IContato contato) {
        int pos = -1;
        for (int i = 0; i < posicaoVaga; i++) {
            if (contatos[i].equals(contato) == true) {
                pos = i;
            }
        }

        return pos;
    }

    @Override// edita a posicao para o contato passado
    public boolean altera(int posicao, IContato contatoEntra) {
        if(validaPosicao(posicao)==true){
            contatos[posicao] = contatoEntra;
            return true;
        }else
            return false;
  
    }
     
    // metodo pra validar a posicao passada
    public boolean validaPosicao(int pos){
         if(pos >= 0 && pos < posicaoVaga)
             return true;
         else 
             return false;
                     
     
     }
   
}
